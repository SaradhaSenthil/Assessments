package com.leaftaps.pages;

import org.openqa.selenium.WebElement;

import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods{
	
	public LoginPage enterUsername(String data) {
		//Step 1"locate the element
		WebElement ele = locateElement("userName");
		
		//step2: Interact with the element 
		clearAndType(ele,data);
		
		//clearAndType(locateElement(Locators.ID, "username"), data);
		
		reportStep("Username is entered successfully","pass");
		//reportStep(data+" entered successfully","pass");
		return this;
	}
	
	public LoginPage enterPassword(String data) {
		
		WebElement ele = locateElement(Locators.XPATH,"//input[@type='password']");
		
		//clearAndType(locateElement(Locators.ID, "password"), data);
		
		clearAndType(ele,data);
		
		reportStep("Password is entered successfully","pass");
		//reportStep(data+" entered successfully","pass");
		return this;
	}
	
	public HomePage clickLogin() {
		click(locateElement(Locators.NAME,"Login"));
		
		//click(locateElement(Locators.CLASS_NAME, "decorativeSubmit"));
		
		reportStep("Login button clicked successfully", "pass");
		return new HomePage();
	}

}
